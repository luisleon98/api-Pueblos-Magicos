insert into public.tipos_usuarios (id, tipo_usuario, created_at, updated_at, deleted_at)
values  (1, 'Admin_Systema', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (2, 'Director_Pueblos_Magicos', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (3, 'Hotelero', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (4, 'Restaurantero', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (5, 'Pueblo_Magico', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (6, 'Turista', '2024-04-11 19:56:36', '2024-04-11 19:56:36', null);