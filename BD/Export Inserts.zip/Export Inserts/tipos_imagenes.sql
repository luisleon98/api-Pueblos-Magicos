insert into public.tipos_imagenes (id, tipo, created_at, updated_at, deleted_at)
values  (1, 'back', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (2, 'galeria', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null);