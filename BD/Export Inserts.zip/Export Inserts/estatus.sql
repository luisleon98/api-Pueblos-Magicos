insert into public.estatus (id, estado, created_at, updated_at, deleted_at)
values  (1, 'En Validación', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (2, 'Aceptado', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (3, 'Con Observaciones', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (4, 'Inactivo', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (5, 'En Revisión', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null),
        (6, 'Atendidas', '2024-04-11 19:56:37', '2024-04-11 19:56:37', null);