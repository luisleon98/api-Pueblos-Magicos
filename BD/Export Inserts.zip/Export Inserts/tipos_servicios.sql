insert into public.tipos_servicios (id, servicio, estatus, created_at, updated_at, deleted_at)
values  (1, 'Hospedaje', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (2, 'Gastronomia', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (3, 'Tours', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (4, 'Sitios', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (5, 'Festividades', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null),
        (6, 'Cerca de ustedes', true, '2024-04-11 19:56:36', '2024-04-11 19:56:36', null);